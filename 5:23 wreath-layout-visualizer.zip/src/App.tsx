import React, { useState, useRef } from 'react';
import { Upload, Eye, Download, RefreshCw, Layers } from 'lucide-react';

export default function App() {
  const [componentImages, setComponentImages] = useState({
    'grapevine-base': null,
    'noble-fir': null,
    'eucalyptus': null,
    'hydrangea': null,
    'rose': null,
    'ornament': null,
    'ribbon': null,
    'light': null
  });
  
  const [selectedLayout, setSelectedLayout] = useState('perfect-symmetry');
  const [currentLayer, setCurrentLayer] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const [showAllLayers, setShowAllLayers] = useState(false);
  const [downloadedImage, setDownloadedImage] = useState(null);
  const [isLit, setIsLit] = useState(false);
  const [lightPositions, setLightPositions] = useState([]);

  // Generate random light positions
  const generateLightPositions = () => {
    const lights = [];
    const numLights = 15 + Math.floor(Math.random() * 10); // 15-25 lights
    
    for (let i = 0; i < numLights; i++) {
      lights.push({
        angle: Math.random() * 360,
        radius: 60 + Math.random() * 80, // Between greenery layers
        size: 8 + Math.random() * 6, // 8-14px lights
        opacity: 0.7 + Math.random() * 0.3, // Varying brightness
        color: Math.random() > 0.1 ? '#ffd700' : '#ffffff' // Mostly warm white, some cool white
      });
    }
    return lights;
  };

  // Toggle lights on/off
  const toggleLights = () => {
    setIsLit(!isLit);
    if (!isLit) {
      setLightPositions(generateLightPositions());
    } else {
      setLightPositions([]);
    }
  };

  // Better z-index layering for realistic wreath construction
  const getComponentZIndex = (componentType, layerIndex) => {
    const zIndexMap = {
      'grapevine-base': 1,
      'noble-fir': 10,
      'ornament': 12, // Between noble fir and eucalyptus  
      'eucalyptus': 15, 
      'hydrangea': 20,
      'rose': 25,
      'ribbon': 30,
      'light': 13 // Between ornaments and eucalyptus
    };
    return zIndexMap[componentType] || layerIndex + 10;
  };

  // Fixed layout templates with proper positioning
  const layouts = {
    'perfect-symmetry': {
      name: 'Perfect Symmetry',
      description: 'Traditional balanced design with mathematical precision',
      layers: [
        {
          name: 'Grapevine Base Foundation',
          component: 'grapevine-base',
          positions: [
            { angle: 0, radius: 0, size: 280 }
          ]
        },
        {
          name: 'Noble Fir Foundation',
          component: 'noble-fir',
          positions: [
            { angle: 0, radius: 120, size: 150 },
            { angle: 51, radius: 120, size: 150 },
            { angle: 103, radius: 120, size: 150 },
            { angle: 154, radius: 120, size: 150 },
            { angle: 206, radius: 120, size: 150 },
            { angle: 257, radius: 120, size: 150 },
            { angle: 309, radius: 120, size: 150 }
          ]
        },
        {
          name: 'Eucalyptus Secondary Layer',
          component: 'eucalyptus',
          positions: [
            { angle: 45, radius: 100, size: 120 },
            { angle: 135, radius: 100, size: 120 },
            { angle: 225, radius: 100, size: 120 },
            { angle: 315, radius: 100, size: 120 }
          ]
        },
        {
          name: 'Ornament Accents',
          component: 'ornament',
          positions: [
            { angle: 37.5, radius: 75, size: 80 },  // Moved closer to center, between layers
            { angle: 112.5, radius: 78, size: 80 }, // Varied radius for natural look
            { angle: 195, radius: 72, size: 80 },   // Nestled within greenery
            { angle: 277.5, radius: 76, size: 80 }  // Between hydrangeas and roses
          ]
        },
        {
          name: 'Hydrangea Focal Points',
          component: 'hydrangea',
          positions: [
            { angle: 60, radius: 80, size: 130 },
            { angle: 180, radius: 80, size: 130 },
            { angle: 300, radius: 80, size: 130 }
          ]
        },
        {
          name: 'Rose Secondary Focals',
          component: 'rose',
          positions: [
            { angle: 330, radius: 85, size: 110 },
            { angle: 90, radius: 85, size: 110 },
            { angle: 210, radius: 85, size: 110 }
          ]
        },
        {
          name: 'Buffalo Plaid Bow',
          component: 'ribbon',
          positions: [
            { angle: 180, radius: 120, size: 180 }
          ]
        }
      ]
    },
    'garden-natural': {
      name: 'Garden Natural',
      description: 'Organic flowing design with natural integration',
      layers: [
        {
          name: 'Grapevine Base Foundation',
          component: 'grapevine-base',
          positions: [
            { angle: 0, radius: 0, size: 280 }
          ]
        },
        {
          name: 'Noble Fir Natural Flow',
          component: 'noble-fir',
          positions: [
            { angle: 330, radius: 118, size: 150 },
            { angle: 0, radius: 122, size: 150 },
            { angle: 30, radius: 119, size: 150 },
            { angle: 120, radius: 115, size: 150 },
            { angle: 150, radius: 117, size: 150 },
            { angle: 240, radius: 116, size: 150 },
            { angle: 270, radius: 114, size: 150 }
          ]
        },
        {
          name: 'Eucalyptus Interwoven',
          component: 'eucalyptus',
          positions: [
            { angle: 315, radius: 103, size: 120 },
            { angle: 60, radius: 105, size: 120 },
            { angle: 135, radius: 107, size: 120 },
            { angle: 255, radius: 104, size: 120 }
          ]
        },
        {
          name: 'Hydrangea Clustered',
          component: 'hydrangea',
          positions: [
            { angle: 45, radius: 85, size: 130 },
            { angle: 75, radius: 88, size: 130 },
            { angle: 210, radius: 86, size: 130 }
          ]
        },
        {
          name: 'Rose Natural Balance',
          component: 'rose',
          positions: [
            { angle: 345, radius: 90, size: 110 },
            { angle: 165, radius: 92, size: 110 },
            { angle: 285, radius: 94, size: 110 }
          ]
        },
        {
          name: 'Ornament Natural Sparkle',
          component: 'ornament',
          positions: [
            { angle: 15, radius: 95, size: 80 },
            { angle: 105, radius: 98, size: 80 },
            { angle: 195, radius: 96, size: 80 },
            { angle: 300, radius: 97, size: 80 }
          ]
        },
        {
          name: 'Buffalo Plaid Bow',
          component: 'ribbon',
          positions: [
            { angle: 180, radius: 125, size: 180 }
          ]
        }
      ]
    },
    'cascading-romance': {
      name: 'Cascading Romance',
      description: 'Flowing design with romantic asymmetrical movement',
      layers: [
        {
          name: 'Grapevine Base Foundation',
          component: 'grapevine-base',
          positions: [
            { angle: 0, radius: 0, size: 280 }
          ]
        },
        {
          name: 'Noble Fir Flowing Foundation',
          component: 'noble-fir',
          positions: [
            { angle: 300, radius: 118, size: 150 },
            { angle: 330, radius: 122, size: 150 },
            { angle: 0, radius: 125, size: 150 },
            { angle: 30, radius: 122, size: 150 },
            { angle: 90, radius: 115, size: 150 },
            { angle: 150, radius: 110, size: 150 },
            { angle: 210, radius: 108, size: 150 }
          ]
        },
        {
          name: 'Eucalyptus Cascading Trail',
          component: 'eucalyptus',
          positions: [
            { angle: 330, radius: 95, size: 120 },
            { angle: 30, radius: 98, size: 120 },
            { angle: 90, radius: 100, size: 120 },
            { angle: 240, radius: 90, size: 120 }
          ]
        },
        {
          name: 'Hydrangea Romantic Clusters',
          component: 'hydrangea',
          positions: [
            { angle: 0, radius: 75, size: 130 },
            { angle: 30, radius: 78, size: 130 },
            { angle: 210, radius: 75, size: 130 }
          ]
        },
        {
          name: 'Rose Scattered Grace',
          component: 'rose',
          positions: [
            { angle: 60, radius: 82, size: 110 },
            { angle: 120, radius: 85, size: 110 },
            { angle: 270, radius: 80, size: 110 }
          ]
        },
        {
          name: 'Ornament Sparkling Trail',
          component: 'ornament',
          positions: [
            { angle: 345, radius: 102, size: 80 },
            { angle: 15, radius: 105, size: 80 },
            { angle: 75, radius: 108, size: 80 },
            { angle: 105, radius: 110, size: 80 }
          ]
        },
        {
          name: 'Buffalo Plaid Bow',
          component: 'ribbon',
          positions: [
            { angle: 150, radius: 125, size: 180 }
          ]
        }
      ]
    },
    'formal-estate': {
      name: 'Formal Estate',
      description: 'Sophisticated symmetrical design for luxury settings',
      layers: [
        {
          name: 'Grapevine Base Foundation',
          component: 'grapevine-base',
          positions: [
            { angle: 0, radius: 0, size: 280 }
          ]
        },
        {
          name: 'Noble Fir Formal Framework',
          component: 'noble-fir',
          positions: [
            { angle: 0, radius: 120, size: 150 },
            { angle: 180, radius: 120, size: 150 },
            { angle: 90, radius: 120, size: 150 },
            { angle: 270, radius: 120, size: 150 },
            { angle: 45, radius: 115, size: 150 },
            { angle: 135, radius: 115, size: 150 },
            { angle: 315, radius: 115, size: 150 }
          ]
        },
        {
          name: 'Eucalyptus Sophisticated Accents',
          component: 'eucalyptus',
          positions: [
            { angle: 30, radius: 100, size: 120 },
            { angle: 150, radius: 100, size: 120 },
            { angle: 210, radius: 100, size: 120 },
            { angle: 330, radius: 100, size: 120 }
          ]
        },
        {
          name: 'Hydrangea Formal Trio',
          component: 'hydrangea',
          positions: [
            { angle: 0, radius: 78, size: 130 },
            { angle: 120, radius: 82, size: 130 },
            { angle: 240, radius: 82, size: 130 }
          ]
        },
        {
          name: 'Rose Elegant Counterpoint',
          component: 'rose',
          positions: [
            { angle: 60, radius: 85, size: 110 },
            { angle: 180, radius: 88, size: 110 },
            { angle: 300, radius: 85, size: 110 }
          ]
        },
        {
          name: 'Ornament Refined Details',
          component: 'ornament',
          positions: [
            { angle: 15, radius: 108, size: 80 },
            { angle: 105, radius: 108, size: 80 },
            { angle: 195, radius: 108, size: 80 },
            { angle: 285, radius: 108, size: 80 }
          ]
        },
        {
          name: 'Buffalo Plaid Bow',
          component: 'ribbon',
          positions: [
            { angle: 180, radius: 120, size: 180 }
          ]
        }
      ]
    },
    'modern-minimalist': {
      name: 'Modern Minimalist',
      description: 'Clean, architectural design with strategic spacing',
      layers: [
        {
          name: 'Grapevine Base Foundation',
          component: 'grapevine-base',
          positions: [
            { angle: 0, radius: 0, size: 280 }
          ]
        },
        {
          name: 'Noble Fir Architectural Framework',
          component: 'noble-fir',
          positions: [
            { angle: 0, radius: 125, size: 150 },
            { angle: 72, radius: 125, size: 150 },
            { angle: 144, radius: 125, size: 150 },
            { angle: 216, radius: 125, size: 150 },
            { angle: 288, radius: 125, size: 150 }
          ]
        },
        {
          name: 'Eucalyptus Minimalist Accents',
          component: 'eucalyptus',
          positions: [
            { angle: 36, radius: 95, size: 120 },
            { angle: 180, radius: 95, size: 120 },
            { angle: 324, radius: 95, size: 120 }
          ]
        },
        {
          name: 'Hydrangea Statement Focals',
          component: 'hydrangea',
          positions: [
            { angle: 90, radius: 75, size: 130 },
            { angle: 270, radius: 75, size: 130 }
          ]
        },
        {
          name: 'Rose Clean Accents',
          component: 'rose',
          positions: [
            { angle: 0, radius: 88, size: 110 },
            { angle: 180, radius: 88, size: 110 }
          ]
        },
        {
          name: 'Ornament Minimal Details',
          component: 'ornament',
          positions: [
            { angle: 45, radius: 110, size: 80 },
            { angle: 225, radius: 110, size: 80 }
          ]
        },
        {
          name: 'Buffalo Plaid Bow',
          component: 'ribbon',
          positions: [
            { angle: 180, radius: 140, size: 180 }
          ]
        }
      ]
    }
  };

  const handleImageUpload = (componentType, event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        // Apply background removal only for ribbon/bow
        if (componentType === 'ribbon') {
          removeImageBackground(e.target.result, (processedImage) => {
            setComponentImages(prev => ({
              ...prev,
              [componentType]: processedImage
            }));
          });
        } else {
          setComponentImages(prev => ({
            ...prev,
            [componentType]: e.target.result
          }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Function to remove background from bow/ribbon images
  const removeImageBackground = (imageUrl, callback) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = img.width;
      canvas.height = img.height;
      
      ctx.drawImage(img, 0, 0);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;
      
      // Remove white and near-white backgrounds
      for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        
        // Remove white and light gray backgrounds
        if (r > 240 && g > 240 && b > 240) {
          data[i + 3] = 0; // Make transparent
        }
      }
      
      ctx.putImageData(imageData, 0, 0);
      callback(canvas.toDataURL());
    };
    img.src = imageUrl;
  };

  const buildWreathByLayers = () => {
    setIsAnimating(true);
    setCurrentLayer(0);
    setShowAllLayers(false);
    
    const interval = setInterval(() => {
      setCurrentLayer(prev => {
        if (prev >= layouts[selectedLayout].layers.length - 1) {
          clearInterval(interval);
          setIsAnimating(false);
          setShowAllLayers(true);
          return prev;
        }
        return prev + 1;
      });
    }, 1500);
  };

  const resetVisualization = () => {
    setCurrentLayer(0);
    setShowAllLayers(false);
    setIsAnimating(false);
  };

  const showAllLayersAtOnce = () => {
    setCurrentLayer(layouts[selectedLayout].layers.length - 1);
    setShowAllLayers(true);
    setIsAnimating(false);
  };

  const convertToCartesian = (angle, radius, centerX = 192, centerY = 192) => {
    const radians = (angle - 90) * Math.PI / 180;
    return {
      x: centerX + radius * Math.cos(radians),
      y: centerY + radius * Math.sin(radians)
    };
  };

  const downloadWreath = async () => {
    try {
      console.log('Download button clicked');
      
      // First check if we have images loaded in the visualizer
      const hasVisibleComponents = Object.values(componentImages).some(img => img !== null);
      
      if (!hasVisibleComponents) {
        alert('Please upload component images first to generate a layout with actual components.');
        return;
      }
      
      // Create high-resolution canvas
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = 1600;
      canvas.height = 1600;
      
      // White background
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, 1600, 1600);
      
      // Add title
      ctx.fillStyle = '#2c2c2c';
      ctx.font = 'bold 48px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(`The Baden Co. - ${layouts[selectedLayout].name}`, 800, 100);
      
      // Add subtitle
      ctx.font = '32px Arial';
      ctx.fillStyle = '#666666';
      ctx.fillText(layouts[selectedLayout].description, 800, 150);
      
      // Draw wreath background circle - matching the visualizer
      const centerX = 800;
      const centerY = 800;
      const wreathRadius = 384 * 2; // Scale up the visualizer circle
      
      // Clean background - no visible border for professional marketing images
      const gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, wreathRadius);
      gradient.addColorStop(0, '#ffffff');
      gradient.addColorStop(1, '#ffffff');
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(centerX, centerY, wreathRadius, 0, 2 * Math.PI);
      ctx.fill();
      
      // Scale factor to match visualizer positioning
      const scale = 4.17; // Scale from 384px visualizer to 1600px canvas
      
      // Draw components in exact same order and positioning as visualizer
      const drawPromises = [];
      
      layouts[selectedLayout].layers.forEach((layer, layerIndex) => {
        const imageData = componentImages[layer.component];
        if (imageData) {
          layer.positions.forEach((pos, posIndex) => {
            const promise = new Promise<void>((resolve) => {
              const img = new Image();
              img.onload = () => {
                // Use same positioning logic as visualizer
                const coords = convertToCartesian(pos.angle, pos.radius * scale, centerX, centerY);
                const size = pos.size * scale;
                
                ctx.save();
                ctx.translate(coords.x, coords.y);
                
                // Use same rotation logic as visualizer
                if (layer.component !== 'ribbon') {
                  const rotation = pos.angle + (posIndex * 15 - 15);
                  ctx.rotate(rotation * Math.PI / 180);
                }
                
                // Draw with same z-index positioning
                ctx.globalCompositeOperation = 'source-over';
                ctx.drawImage(img, -size/2, -size/2, size, size);
                ctx.restore();
                resolve();
              };
              img.onerror = () => resolve();
              img.src = imageData;
            });
            drawPromises.push(promise);
          });
        }
      });
      
      // Wait for all images to load
      await Promise.all(drawPromises);
      
      // Add Christmas lights if enabled
      if (isLit && lightPositions.length > 0 && componentImages.light) {
        lightPositions.forEach((light, index) => {
          const coords = convertToCartesian(light.angle, light.radius * scale, centerX, centerY);
          const lightSize = light.size * scale;
          
          const promise = new Promise<void>((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
              ctx.save();
              ctx.translate(coords.x, coords.y);
              ctx.rotate(light.angle * Math.PI / 180);
              ctx.globalAlpha = light.opacity;
              ctx.drawImage(img, -lightSize/2, -lightSize/2, lightSize, lightSize);
              ctx.restore();
              resolve();
            };
            img.onerror = () => resolve();
            img.src = componentImages.light;
          });
          drawPromises.push(promise);
        });
      }
      
      // Convert to data URL and display
      const dataURL = canvas.toDataURL('image/png', 1.0);
      setDownloadedImage(dataURL);
      
      console.log('High-resolution image generated matching visualizer');
      
    } catch (error) {
      console.error('Download error:', error);
      alert(`Download failed: ${error.message}`);
    }
  };

  const componentLabels = {
    'grapevine-base': '24" Grapevine Base',
    'noble-fir': 'Noble Fir Spray',
    'eucalyptus': 'Silver Dollar Eucalyptus',
    'hydrangea': 'White Hydrangea',
    'rose': 'English Charlotte Rose',
    'ornament': 'Silver Ornament',
    'ribbon': 'Buffalo Plaid Ribbon',
    'light': 'LED Light Bulb'
  };

  return (
    <div className="min-h-screen bg-bg p-6 font-sans">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-serif text-ink mb-2">The Baden Co.</h1>
          <h2 className="text-2xl font-sans font-normal uppercase tracking-widest text-ink/70">Professional Layout Visualizer</h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Upload Panel */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-none shadow-none border border-ink/10 p-6 mb-6">
              <h3 className="text-base font-serif text-ink mb-4 flex items-center">
                <Upload className="w-5 h-5 mr-2" />
                Component Images
              </h3>
              
              <div className="space-y-4">
                {Object.entries(componentLabels).map(([key, label]) => (
                  <div key={key} className="border rounded-lg p-3">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {label}
                    </label>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleImageUpload(key, e)}
                      className="block w-full text-sm text-gray-500 file:mr-4 file:py-1 file:px-3 file:rounded file:border-0 file:text-xs file:font-medium file:bg-gray-100 file:text-gray-700 hover:file:bg-gray-200"
                    />
                    {componentImages[key] && (
                      <div className="mt-2">
                        <img 
                          src={componentImages[key]} 
                          alt={label}
                          className="w-16 h-16 object-cover rounded border"
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Layout Selection */}
            <div className="bg-white rounded-none shadow-none border border-ink/10 p-6">
              <h3 className="text-base font-serif text-ink mb-4">Layout Templates</h3>
              
              <div className="space-y-3">
                {Object.entries(layouts).map(([key, layout]) => (
                  <div key={key} className="border border-ink/10 rounded-none p-3">
                    <label className="flex items-center">
                      <input
                        type="radio"
                        name="layout"
                        value={key}
                        checked={selectedLayout === key}
                        onChange={(e) => setSelectedLayout(e.target.value)}
                        className="mr-3 accent-accent"
                      />
                      <div>
                        <div className="font-bold uppercase tracking-tight text-ink">{layout.name}</div>
                        <div className="text-xs text-ink/60">{layout.description}</div>
                      </div>
                    </label>
                  </div>
                ))}
              </div>

              <div className="mt-6 space-y-2">
                {/* Lit/Unlit Toggle */}
                <div className="flex items-center justify-between p-3 border border-ink/10 rounded-none bg-white">
                  <span className="text-sm font-bold uppercase tracking-tight text-ink">Lighting:</span>
                  <button
                    onClick={toggleLights}
                    className={`px-4 py-2 text-xs font-bold uppercase tracking-tight transition-colors ${
                      isLit 
                        ? 'bg-accent text-white' 
                        : 'bg-ink text-white'
                    }`}
                  >
                    {isLit ? '✨ Lit' : '🌙 Unlit'}
                  </button>
                </div>
                
                <button
                  onClick={buildWreathByLayers}
                  disabled={isAnimating}
                  className="w-full flex items-center justify-center px-4 py-2 bg-ink text-white font-bold uppercase tracking-tight disabled:opacity-50"
                >
                  <Layers className="w-4 h-4 mr-2" />
                  {isAnimating ? 'Building...' : 'Build by Layers'}
                </button>
                
                <button
                  onClick={showAllLayersAtOnce}
                  className="w-full flex items-center justify-center px-4 py-2 border border-ink/10 text-ink font-bold uppercase tracking-tight hover:bg-ink hover:text-white"
                >
                  <Eye className="w-4 h-4 mr-2" />
                  Show Complete
                </button>
                
                <button
                  onClick={resetVisualization}
                  className="w-full flex items-center justify-center px-4 py-2 border border-ink/10 text-ink font-bold uppercase tracking-tight hover:bg-ink hover:text-white"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Reset
                </button>
                
                <button
                  onClick={downloadWreath}
                  className="w-full flex items-center justify-center px-4 py-2 bg-accent text-white font-bold uppercase tracking-tight hover:bg-accent/90"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Generate Image
                </button>
              </div>
              
              {/* Generated Image Display */}
              {downloadedImage && (
                <div className="mt-4 p-4 border rounded-lg bg-gray-50">
                  <h4 className="font-medium text-gray-800 mb-2">Generated Layout Template:</h4>
                  <img 
                    src={downloadedImage} 
                    alt="Generated Layout Template"
                    className="w-full border rounded"
                  />
                  <div className="mt-2 text-xs text-gray-600">
                    Right-click image above and select "Save image as..." to download
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Visualization Area */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-none border border-ink/10 p-6">
              <div className="flex justify-between items-center mb-8 border-b border-ink/10 pb-4">
                <h3 className="text-2xl font-serif text-ink">
                  {layouts[selectedLayout].name}
                </h3>
                {isAnimating && (
                  <div className="text-xs font-bold uppercase tracking-tight text-accent">
                    Building {currentLayer + 1} / {layouts[selectedLayout].layers.length}...
                  </div>
                )}
              </div>
              
              <div className="relative">
                <div 
                  className="w-96 h-96 mx-auto relative bg-gradient-to-br from-amber-50 to-amber-100 rounded-full border-4 border-amber-200 overflow-visible"
                  style={{ 
                    backgroundImage: 'radial-gradient(circle at center, rgba(139, 69, 19, 0.1) 0%, rgba(139, 69, 19, 0.05) 70%, transparent 70%)',
                  }}
                >
                  {/* Grapevine base texture */}
                  <div className="absolute inset-4 rounded-full border-2 border-dashed border-amber-300 opacity-30"></div>
                  
                  {/* Rendered Components with proper layering */}
                  {layouts[selectedLayout].layers.map((layer, layerIndex) => {
                    const shouldShow = showAllLayers || layerIndex <= currentLayer;
                    const image = componentImages[layer.component];
                    
                    if (!shouldShow || !image) return null;
                    
                    return layer.positions.map((pos, posIndex) => {
                      const coords = convertToCartesian(pos.angle, pos.radius, 192, 192);
                      
                      return (
                        <div
                          key={`${layerIndex}-${posIndex}`}
                          className="absolute transition-all duration-500 ease-in-out"
                          style={{
                            left: coords.x - pos.size/2,
                            top: coords.y - pos.size/2,
                            width: pos.size,
                            height: pos.size,
                            zIndex: getComponentZIndex(layer.component, layerIndex),
                            opacity: shouldShow ? (layerIndex === currentLayer && isAnimating ? 0.8 : 1) : 0,
                            transform: layer.component === 'ribbon' ? 'none' : `rotate(${pos.angle + (posIndex * 15 - 15)}deg)`
                          }}
                        >
                          <img 
                            src={image}
                            alt={`${layer.name} ${posIndex + 1}`}
                            className="w-full h-full object-contain"
                            style={{ 
                              filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.1))',
                              maxWidth: '100%',
                              maxHeight: '100%'
                            }}
                            onError={(e) => {
                              console.log(`Failed to load image for ${layer.component}`);
                              e.target.style.display = 'none';
                            }}
                          />
                        </div>
                      );
                    });
                  })}

                  {/* Christmas Lights Layer - Using uploaded light image */}
                  {isLit && componentImages.light && lightPositions.map((light, index) => {
                    const coords = convertToCartesian(light.angle, light.radius, 192, 192);
                    return (
                      <div
                        key={`light-${index}`}
                        className="absolute transition-all duration-500 ease-in-out"
                        style={{
                          left: coords.x - light.size/2,
                          top: coords.y - light.size/2,
                          width: light.size,
                          height: light.size,
                          zIndex: getComponentZIndex('light', 0),
                          opacity: light.opacity,
                          transform: `rotate(${light.angle}deg)`
                        }}
                      >
                        <img 
                          src={componentImages.light}
                          alt={`LED Light ${index + 1}`}
                          className="w-full h-full object-contain"
                          style={{ 
                            filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.1))',
                            maxWidth: '100%',
                            maxHeight: '100%'
                          }}
                        />
                      </div>
                    );
                  })}

                  {/* Center guide */}
                  <div className="absolute top-1/2 left-1/2 w-2 h-2 bg-amber-400 rounded-full transform -translate-x-1/2 -translate-y-1/2 opacity-50"></div>
                </div>
                
                {/* Component Loading Status */}
                <div className="mt-6 grid grid-cols-3 gap-2">
                  {Object.entries(componentLabels).map(([key, label]) => (
                    <div key={key} className="text-xs text-center">
                      <div className={`w-3 h-3 rounded-full mx-auto mb-1 ${componentImages[key] ? 'bg-green-500' : 'bg-red-500'}`}></div>
                      <div className="text-gray-600">{label.split(' ')[0]}</div>
                    </div>
                  ))}
                </div>
                
                {/* Layer Information */}
                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h4 className="font-medium text-gray-800 mb-2">Current Layer</h4>
                    {isAnimating || showAllLayers ? (
                      <div className="text-sm text-gray-600">
                        {showAllLayers ? 'All Layers Complete' : layouts[selectedLayout].layers[currentLayer]?.name}
                      </div>
                    ) : (
                      <div className="text-sm text-gray-500">Click "Build by Layers" to start</div>
                    )}
                  </div>
                  
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h4 className="font-medium text-gray-800 mb-2">Components Placed</h4>
                    <div className="text-sm text-gray-600">
                      {showAllLayers ? 
                        `${layouts[selectedLayout].layers.reduce((total, layer) => total + layer.positions.length, 0)} total pieces` :
                        `${layouts[selectedLayout].layers.slice(0, currentLayer + 1).reduce((total, layer) => total + layer.positions.length, 0)} pieces so far`
                      }
                      {isLit && <div className="text-xs text-yellow-600 mt-1">✨ {lightPositions.length} LED lights added</div>}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
